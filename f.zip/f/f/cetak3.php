<?php 
    session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['level']==""){
        header("location:index.php?pesan=gagal");
    }
 
    ?>
    <?php 
require 'functions3.php';
$transaksi = query("SELECT * FROM transaksi");

// tombol cari ditekan
if( isset($_POST["cari"]) ) {
    $transaksi = cari($_POST["keyword"]);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Halaman Kepala Perpus</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<h1>Daftar transaksi</h1>
<center>
<br>
<table border="1" cellpadding="10" cellspacing="0">

    <tr>
        <th>No.</th>
        <th>Nama Buku</th>
        <th>Nama Anggota</th>
        <th>Status</th>
        <th>Tanggal Pinjam</th>
        <th>Lama Pinjam</th>
        <th>Tanggal Kembali</th>
        <th>Denda</th>
    </tr>

    <?php $i = 1; ?>
    <?php foreach( $transaksi as $row ) : ?>
    <tr>
        <td><?= $i; ?></td>
        <td><?= $row["namabuku"]; ?></td>
        <td><?= $row["namaanggota"]; ?></td>
        <td><?= $row["status"]; ?></td>
        <td><?= $row["tanggalpinjam"]; ?></td>
        <td><?= $row["lamapinjam"]; ?></td>
        <td><?= $row["tanggalkembali"]; ?></td>
        <td><?= $row["denda"]; ?></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
    
</table>
</center>
<script>
    window.print();
    </script>
</body>
</html>

</body>
</html>