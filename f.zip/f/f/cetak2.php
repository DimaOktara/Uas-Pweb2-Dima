<?php 
    session_start();
 
    // cek apakah yang mengakses halaman ini sudah login
    if($_SESSION['level']==""){
        header("location:index.php?pesan=gagal");
    }
 
    ?>
    <?php 
require 'functions2.php';
$buku = query("SELECT * FROM buku");

// tombol cari ditekan
if( isset($_POST["cari"]) ) {
    $buku = cari($_POST["keyword"]);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Halaman Kepala Perpus</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<h1>Daftar Buku</h1>
<center>
<br>
<table border="1" cellpadding="10" cellspacing="0">

    <tr>
        <th>No.</th>
        <th>Judul Buku</th>
        <th>Isbn</th>
        <th>Penerbit</th>
        <th>Tahun Terbit</th>
        <th>Stok Buku</th>
        <th>Dipinjam</th>
        <th>Tanggal Masuk</th>
        <th>Sampul</th>
    </tr>

    <?php $i = 1; ?>
    <?php foreach( $buku as $row ) : ?>
    <tr>
        <td><?= $i; ?></td>
        <td><?= $row["title"]; ?></td>
        <td><?= $row["isbn"]; ?></td>
        <td><?= $row["penerbit"]; ?></td>
        <td><?= $row["tahunterbit"]; ?></td>
        <td><?= $row["stokbuku"]; ?></td>
        <td><?= $row["dipinjam"]; ?></td>
        <td><?= $row["tanggalmasuk"]; ?></td>
        <td><img src="img/<?= $row["gambar"]; ?>" width="50"></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
    
</table>
</center>
<script>
    window.print();
    </script>
</body>
</html>

</body>
</html>