<?php 
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "perpustakaan");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}
 

function tambah($data) {
	global $conn;

	$namabuku = ($data["namabuku"]);
	$namaanggota = ($data["namaanggota"]);
	$status = ($data["status"]);
	$tanggalpinjam = ($data["tanggalpinjam"]);
	$lamapinjam = ($data["lamapinjam"]);
	$tanggalkembali = ($data["tanggalkembali"]);
	$denda = ($data["denda"]);

	$query = "INSERT INTO transaksi
				VALUES
			  ('', '$namabuku', '$namaanggota', '$status', '$tanggalpinjam', '$lamapinjam', '$tanggalkembali','$denda')
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}



function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM transaksi WHERE id = $id");
	return mysqli_affected_rows($conn);
}


function ubah($data) {
	global $conn;

	$id = $data["id"];
	$namabuku = ($data["namabuku"]);
	$namaanggota = ($data["namaanggota"]);
	$status = ($data["status"]);
	$tanggalpinjam = ($data["tanggalpinjam"]);
	$lamapinjam = ($data["lamapinjam"]);
	$tanggalkembali = ($data["tanggalkembali"]);
	$denda = ($data["denda"]);
	

	$query = "UPDATE transaksi SET
				namabuku = '$namabuku',
				namaanggota = '$namaanggota',
				status = '$status',
				tanggalpinjam = '$tanggalpinjam',
				lamapinjam = '$lamapinjam',
				tanggalkembali = '$tanggalkembali',
				denda = '$denda'
			  WHERE id = $id
			";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);	
}


function cari($keyword) {
	$query = "SELECT * FROM transaksi
				WHERE
			  namaanggota LIKE '%$keyword%' OR
			  namabuku LIKE '%$keyword%' OR
			  status LIKE '%$keyword%'
			";
	return query($query);
}


?>
