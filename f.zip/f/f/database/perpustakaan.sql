-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2024 at 05:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `isbn` int(15) NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `tahunterbit` int(11) NOT NULL,
  `stokbuku` int(11) NOT NULL,
  `dipinjam` int(11) NOT NULL,
  `tanggalmasuk` date NOT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `title`, `isbn`, `penerbit`, `tahunterbit`, `stokbuku`, `dipinjam`, `tanggalmasuk`, `gambar`) VALUES
(1, 'Cara Menulis Proposal Penilitian', 134, 'Wahyudin Damalaksana', 2020, 25, 2, '2023-04-04', '659a27d1af757.jpeg'),
(3, 'Dia adalah Dilanku 1990', 123, 'Pidi Baiq', 2022, 20, 5, '2022-06-13', '659a27da8c866.jpeg'),
(5, 'Dibawah Lindungan Ka\'bah', 147, 'Hamka', 2021, 23, 3, '2021-01-20', '5.jpeg'),
(9, 'Think and Grow Rich', 184, 'Napoleon Hill', 2022, 30, 3, '2023-03-05', '659a283fec840.jpeg'),
(10, 'Tenggelamnya Kapal Van der Wijck', 152, 'Hamka', 2021, 27, 5, '2023-09-18', '659a28983c9ed.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nim` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jeniskelamin` enum('pria','wanita') NOT NULL,
  `tanggallahir` date NOT NULL,
  `fakultas` varchar(100) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `nohp` char(100) DEFAULT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nim`, `nama`, `alamat`, `jeniskelamin`, `tanggallahir`, `fakultas`, `jurusan`, `nohp`, `gambar`) VALUES
(1, '7011220024', 'Nadia Oktarina', 'Palembang sumsel', 'wanita', '2003-10-01', 'Saintek', 'Sistem Informasi', '082278659630', '659a1fbf48162.jpeg'),
(6, '7011220025', 'Risa', 'Jambi', 'wanita', '2006-12-06', 'Febi', 'Ekonomi', '082367854426', '659a20487374f.jpeg'),
(11, '7011220027', 'Falih Gumilang', 'Riau', 'pria', '2003-05-13', 'Ushuludin', 'Ilmu Pemerintahan', '082278973478', '659a20967d0fe.jpeg'),
(15, '7011220029', 'Fawwaz', 'Kerinci', 'pria', '2003-09-14', 'Syariah', 'Hukum Tata Negara', '0822675380', '659a211915fc2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `namabuku` varchar(255) DEFAULT NULL,
  `namaanggota` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `tanggalpinjam` date DEFAULT NULL,
  `lamapinjam` varchar(50) DEFAULT NULL,
  `tanggalkembali` date DEFAULT NULL,
  `denda` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `namabuku`, `namaanggota`, `status`, `tanggalpinjam`, `lamapinjam`, `tanggalkembali`, `denda`) VALUES
(1, 'Impian 100 cahaya', 'nadia', 'belum dikembalikan', '2024-01-25', '7', '2023-12-22', '5000'),
(2, 'seribu janji', 'haikal', 'sudah dikembalikan', '2023-12-26', '3', '2023-12-28', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1, 'kepala perpus', 'kepala perpus', 'kepala perpus123', 'kepala perpus'),
(2, 'admin', 'admin', 'admin123', 'admin'),
(3, 'mahasiswa', 'mahasiswa', 'mahasiswa123', 'mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
